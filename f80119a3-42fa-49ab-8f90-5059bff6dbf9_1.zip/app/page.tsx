
'use client';

import Header from '@/components/Header';
import Footer from '@/components/Footer';
import Link from 'next/link';

export default function Home() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      
      {/* Hero Section */}
      <section className="relative bg-gradient-to-r from-blue-600 to-blue-800 text-white overflow-hidden">
        <div className="absolute inset-0 bg-black/20"></div>
        <div 
          className="absolute inset-0 bg-cover bg-center bg-no-repeat"
          style={{
            backgroundImage: `url('https://readdy.ai/api/search-image?query=Professional%20business%20consultant%20working%20with%20documents%20and%20laptop%20in%20a%20modern%20office%20environment%2C%20corporate%20setting%20with%20charts%20and%20graphs%2C%20clean%20blue%20and%20white%20color%20scheme%2C%20business%20success%20concept%2C%20professional%20lighting&width=1200&height=600&seq=hero-bg&orientation=landscape')`
          }}
        ></div>
        <div className="relative container mx-auto px-4 py-20">
          <div className="max-w-3xl">
            <h1 className="text-5xl md:text-6xl font-bold mb-6 leading-tight">
              Empowering Your MSME Journey with Expert Guidance
            </h1>
            <p className="text-xl md:text-2xl mb-8 text-blue-100">
              Your trusted partner for MSME registration, compliance, and growth in Prayagraj. Get professional support from Ajay Kumar, your local MSME expert.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Link href="/contact" className="bg-orange-500 text-white px-8 py-4 rounded-lg text-lg font-semibold hover:bg-orange-600 transition-colors cursor-pointer whitespace-nowrap inline-block text-center">
                Get Free Consultation
              </Link>
              <Link href="/services" className="bg-transparent border-2 border-white text-white px-8 py-4 rounded-lg text-lg font-semibold hover:bg-white hover:text-blue-600 transition-colors cursor-pointer whitespace-nowrap inline-block text-center">
                Explore Services
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-6">
                Meet Ajay Kumar
              </h2>
              <p className="text-lg text-gray-600 mb-6">
                With over 8 years of experience in MSME consultancy, I've helped hundreds of businesses in Prayagraj and surrounding areas navigate the complexities of government schemes, registrations, and compliance requirements.
              </p>
              <p className="text-lg text-gray-600 mb-6">
                Based in Soraon, Prayagraj, I understand the unique challenges faced by local entrepreneurs and provide personalized solutions that drive real results.
              </p>
              <div className="flex flex-wrap gap-4 mb-6">
                <div className="flex items-center bg-blue-100 px-4 py-2 rounded-full">
                  <i className="ri-check-line text-blue-600 mr-2"></i>
                  <span className="text-blue-800 font-semibold">500+ Successful Registrations</span>
                </div>
                <div className="flex items-center bg-green-100 px-4 py-2 rounded-full">
                  <i className="ri-check-line text-green-600 mr-2"></i>
                  <span className="text-green-800 font-semibold">Local Prayagraj Expert</span>
                </div>
                <div className="flex items-center bg-orange-100 px-4 py-2 rounded-full">
                  <i className="ri-check-line text-orange-600 mr-2"></i>
                  <span className="text-orange-800 font-semibold">8+ Years Experience</span>
                </div>
              </div>
              <Link href="/about" className="bg-blue-600 text-white px-6 py-3 rounded-lg hover:bg-blue-700 transition-colors cursor-pointer whitespace-nowrap inline-block">
                Learn More About Me
              </Link>
            </div>
            <div className="relative">
              <img 
                src="https://readdy.ai/api/search-image?query=Professional%20Indian%20business%20consultant%20Ajay%20Kumar%20in%20formal%20attire%2C%20sitting%20at%20desk%20with%20documents%20and%20computer%2C%20friendly%20smile%2C%20office%20background%20with%20certificates%20and%20awards%2C%20professional%20headshot%20style%2C%20clean%20lighting&width=600&height=700&seq=ajay-photo&orientation=portrait"
                alt="Ajay Kumar - MSME Consultant"
                className="rounded-lg shadow-lg w-full object-cover object-top"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Our Services
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Comprehensive MSME solutions tailored to your business needs
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            <div className="bg-white p-6 rounded-lg shadow-lg border border-gray-100 hover:shadow-xl transition-shadow">
              <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                <i className="ri-building-line text-blue-600 text-2xl"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">MSME/Udyam Registration</h3>
              <p className="text-gray-600 mb-4">Complete registration process for Micro, Small & Medium Enterprises under the new Udyam system.</p>
              <Link href="/services" className="text-blue-600 hover:text-blue-800 font-semibold cursor-pointer">
                Learn More →
              </Link>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-lg border border-gray-100 hover:shadow-xl transition-shadow">
              <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mb-4">
                <i className="ri-shield-check-line text-green-600 text-2xl"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Compliance Support</h3>
              <p className="text-gray-600 mb-4">Ensure your business meets all regulatory requirements with our comprehensive compliance assistance.</p>
              <Link href="/services" className="text-blue-600 hover:text-blue-800 font-semibold cursor-pointer">
                Learn More →
              </Link>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-lg border border-gray-100 hover:shadow-xl transition-shadow">
              <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center mb-4">
                <i className="ri-money-dollar-circle-line text-orange-600 text-2xl"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Loan/Grant Assistance</h3>
              <p className="text-gray-600 mb-4">Access funding opportunities and government schemes designed specifically for MSMEs.</p>
              <Link href="/services" className="text-blue-600 hover:text-blue-800 font-semibold cursor-pointer">
                Learn More →
              </Link>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-lg border border-gray-100 hover:shadow-xl transition-shadow">
              <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center mb-4">
                <i className="ri-calculator-line text-purple-600 text-2xl"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">GST/Tax Consultation</h3>
              <p className="text-gray-600 mb-4">Navigate GST regulations and tax compliance with expert guidance and support.</p>
              <Link href="/services" className="text-blue-600 hover:text-blue-800 font-semibold cursor-pointer">
                Learn More →
              </Link>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-lg border border-gray-100 hover:shadow-xl transition-shadow">
              <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center mb-4">
                <i className="ri-file-text-line text-red-600 text-2xl"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Project Report Preparation</h3>
              <p className="text-gray-600 mb-4">Professional project reports for loan applications and business planning.</p>
              <Link href="/services" className="text-blue-600 hover:text-blue-800 font-semibold cursor-pointer">
                Learn More →
              </Link>
            </div>

            <div className="bg-white p-6 rounded-lg shadow-lg border border-gray-100 hover:shadow-xl transition-shadow">
              <div className="w-12 h-12 bg-indigo-100 rounded-lg flex items-center justify-center mb-4">
                <i className="ri-government-line text-indigo-600 text-2xl"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-3">Government Schemes</h3>
              <p className="text-gray-600 mb-4">Stay updated and apply for the latest government schemes and subsidies for MSMEs.</p>
              <Link href="/services" className="text-blue-600 hover:text-blue-800 font-semibold cursor-pointer">
                Learn More →
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-16 bg-blue-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Why Choose AK Consultancy?
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Your success is our priority. Here's why businesses in Prayagraj trust us.
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-blue-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-user-star-line text-white text-2xl"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Expert Guidance</h3>
              <p className="text-gray-600">8+ years of specialized MSME consulting experience</p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-green-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-map-pin-line text-white text-2xl"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Local Expertise</h3>
              <p className="text-gray-600">Deep understanding of Prayagraj business landscape</p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-orange-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-time-line text-white text-2xl"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Quick Turnaround</h3>
              <p className="text-gray-600">Fast and efficient service delivery</p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-purple-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="ri-customer-service-line text-white text-2xl"></i>
              </div>
              <h3 className="text-xl font-semibold text-gray-900 mb-2">Personalized Support</h3>
              <p className="text-gray-600">Dedicated attention to your unique business needs</p>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              What Our Clients Say
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Real stories from businesses we've helped succeed
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-gray-50 p-6 rounded-lg">
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 bg-blue-600 rounded-full flex items-center justify-center mr-4">
                  <span className="text-white font-bold">RK</span>
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900">Rajesh Kumar</h4>
                  <p className="text-gray-600 text-sm">Manufacturing Business</p>
                </div>
              </div>
              <p className="text-gray-700 mb-4">
                "Ajay sir helped us complete our MSME registration in just 3 days. His knowledge of government schemes is exceptional. Highly recommended!"
              </p>
              <div className="flex text-yellow-500">
                <i className="ri-star-fill"></i>
                <i className="ri-star-fill"></i>
                <i className="ri-star-fill"></i>
                <i className="ri-star-fill"></i>
                <i className="ri-star-fill"></i>
              </div>
            </div>

            <div className="bg-gray-50 p-6 rounded-lg">
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 bg-green-600 rounded-full flex items-center justify-center mr-4">
                  <span className="text-white font-bold">PS</span>
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900">Priya Sharma</h4>
                  <p className="text-gray-600 text-sm">Textile Business</p>
                </div>
              </div>
              <p className="text-gray-700 mb-4">
                "Professional service and great support throughout the loan application process. AK Consultancy made everything so simple for us."
              </p>
              <div className="flex text-yellow-500">
                <i className="ri-star-fill"></i>
                <i className="ri-star-fill"></i>
                <i className="ri-star-fill"></i>
                <i className="ri-star-fill"></i>
                <i className="ri-star-fill"></i>
              </div>
            </div>

            <div className="bg-gray-50 p-6 rounded-lg">
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 bg-orange-600 rounded-full flex items-center justify-center mr-4">
                  <span className="text-white font-bold">VG</span>
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900">Vikash Gupta</h4>
                  <p className="text-gray-600 text-sm">Food Processing</p>
                </div>
              </div>
              <p className="text-gray-700 mb-4">
                "Thanks to Ajay sir's guidance, we received a government subsidy that helped us expand our business. Excellent service!"
              </p>
              <div className="flex text-yellow-500">
                <i className="ri-star-fill"></i>
                <i className="ri-star-fill"></i>
                <i className="ri-star-fill"></i>
                <i className="ri-star-fill"></i>
                <i className="ri-star-fill"></i>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-gradient-to-r from-blue-600 to-blue-800 text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Ready to Start Your MSME Journey?
          </h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto">
            Get expert guidance and support for your business registration and compliance needs. Contact us today for a free consultation.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/contact" className="bg-orange-500 text-white px-8 py-4 rounded-lg text-lg font-semibold hover:bg-orange-600 transition-colors cursor-pointer whitespace-nowrap inline-block">
              Get Free Consultation
            </Link>
            <a href="tel:+919876543210" className="bg-transparent border-2 border-white text-white px-8 py-4 rounded-lg text-lg font-semibold hover:bg-white hover:text-blue-600 transition-colors cursor-pointer whitespace-nowrap inline-block">
              Call Now: +91 9876543210
            </a>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}
