
'use client';

import { useState } from 'react';
import Link from 'next/link';

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="bg-white shadow-md sticky top-0 z-50">
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          <Link href="/" className="text-2xl font-bold text-blue-600" style={{ fontFamily: 'var(--font-pacifico)' }}>
            AK Consultancy
          </Link>
          
          <nav className="hidden md:flex items-center space-x-8">
            <Link href="/" className="text-gray-700 hover:text-blue-600 transition-colors cursor-pointer">
              Home
            </Link>
            <Link href="/services" className="text-gray-700 hover:text-blue-600 transition-colors cursor-pointer">
              Services
            </Link>
            <Link href="/about" className="text-gray-700 hover:text-blue-600 transition-colors cursor-pointer">
              About Us
            </Link>
            <Link href="/blog" className="text-gray-700 hover:text-blue-600 transition-colors cursor-pointer">
              Blog
            </Link>
            <Link href="/contact" className="text-gray-700 hover:text-blue-600 transition-colors cursor-pointer">
              Contact
            </Link>
            <Link href="/contact" className="bg-orange-500 text-white px-4 py-2 rounded-lg hover:bg-orange-600 transition-colors cursor-pointer whitespace-nowrap">
              Free Consultation
            </Link>
          </nav>

          <button 
            className="md:hidden w-6 h-6 flex items-center justify-center cursor-pointer"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            <i className="ri-menu-line text-xl"></i>
          </button>
        </div>

        {isMenuOpen && (
          <div className="md:hidden bg-white border-t">
            <nav className="flex flex-col py-4 space-y-2">
              <Link href="/" className="px-4 py-2 text-gray-700 hover:text-blue-600 cursor-pointer">
                Home
              </Link>
              <Link href="/services" className="px-4 py-2 text-gray-700 hover:text-blue-600 cursor-pointer">
                Services
              </Link>
              <Link href="/about" className="px-4 py-2 text-gray-700 hover:text-blue-600 cursor-pointer">
                About Us
              </Link>
              <Link href="/blog" className="px-4 py-2 text-gray-700 hover:text-blue-600 cursor-pointer">
                Blog
              </Link>
              <Link href="/contact" className="px-4 py-2 text-gray-700 hover:text-blue-600 cursor-pointer">
                Contact
              </Link>
              <div className="px-4 py-2">
                <Link href="/contact" className="bg-orange-500 text-white px-4 py-2 rounded-lg hover:bg-orange-600 transition-colors cursor-pointer whitespace-nowrap inline-block">
                  Free Consultation
                </Link>
              </div>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
}
